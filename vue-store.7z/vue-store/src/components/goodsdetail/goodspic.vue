<!--页面下方图片展示区域-->
<template>
    <div>
        <img src="" alt="">
    </div>
</template>
<script>
    export default {
        props : [],
        data(){
           
        }
    }
</script>