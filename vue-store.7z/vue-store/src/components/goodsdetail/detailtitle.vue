 <!--左上侧测搜索头 
 标签的值应为查询页传过来的值，然后再一级一级渲染

 -->
<template>
    <el-breadcrumb separator="/" class="detailtitle">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>一级列表</el-breadcrumb-item>
        <el-breadcrumb-item>二级列表</el-breadcrumb-item>
        <el-breadcrumb-item>三级详情</el-breadcrumb-item>
        <el-breadcrumb-item>商品详情</el-breadcrumb-item>
    </el-breadcrumb>
</template>
<script>

    export default {
        name : 'detailtitle',
        data(){
            return{

            }
        }
    }
</script>
