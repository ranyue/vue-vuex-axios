<!--商品一个主图及四个附图 及下面的数据显示-->
<template>
    <div>
        <div>
            <img src="" alt="">主图
        </div>
        <div>
            <img src="" alt="">附图
            <img src="" alt="">
            <img src="" alt="">
            <img src="" alt="">
        </div>
        <div class="goodsshow-data">
            <div>
                <i>编号<i><i>fx0010</i>
            </div>
            <div>
                <i>LC编号<i><i>fx0010</i>
            </div>

        </div>
    </div>
</template>
<script>
    export default {
        name : 'goodsshow',
        props : [],
        data(){
            return{

            }
        }

    }
</script>