 <!--商品价格统计
 
 -->

<template>
    <div>
        <div>
            <span>已选{{number}}个</span>
            <span>￥{{amount}}</span>
        </div>
       <button type="submit" v-bind:click="addtoshoppingcart">加入购物车</button>
    </div>
</template>
<script>
    export default {
        name : 'goodssubtotal',
        props : [商品编号,数量,价格],
        data(){
            return{
                number : 0,
                amount : 0,
            }
        },
        methods : {
            addtoshoppingcart : this.$store.commit(type.addtoshopingcart,{
                商品编号 : '',
                数量 : '',
                价格 : '',
            })
        }
    }
</script>