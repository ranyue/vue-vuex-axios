<template>
        <div class="goods-checked-detail">
            <div>
                已选中的商品型号
            </div>
            <div>
                商品价格及相关信息
            </div>
            <div>
                <!--购买数量-->
                <el-input-number v-model="num5"></el-input-number>
            </div>
        </div>
</template>

<script>
  export default {
    data() {
      return {
        num5: 1
      }
    }
  };
</script>