<!--底部的商品信息-->
<template>
    <div>
        <ul>
            <li><span>单位</span><span>支</span></li>
            <li><span>单位</span><span>支</span></li>
            <li><span>单位</span><span>支</span></li>
            <li><span>单位</span><span>支</span></li>
            <li><span>单位</span><span>支</span></li>
        </ul>
    </div>
</template>
<script>
    export default {
        props : [],
        data(){

        }
    }
</script>