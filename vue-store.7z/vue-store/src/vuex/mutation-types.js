export const EXAMPLE = 'EXAMPLE';

