import * as types from '../mutation-types'

// initial state
// shape: [{ id, quantity }]


const state = {
   
}

// getters
const getters = {
  
}

// actions
const actions = {
  
}


// mutations
const mutations = {
  
  
}

export default {
  state,
  getters,
  actions,
  mutations
}
