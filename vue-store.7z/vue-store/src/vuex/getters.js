export const example = state => {
  //doSomeThing
  return  state
}
