import * as types from './mutation-types'

export const example = ({ commit }, product) => {
  
}
