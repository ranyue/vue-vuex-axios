<template>
	<div class="goods-item">
		<div>
			<input type="checkbox" name="" value="">
			<div>
				<img :src="goods.goodsImage" alt="">
			</div>
		</div>
		<div>
			<div class='ellipsis-3'>{{goods.goodsName}}</div>
			<div class='ellipsis-3'> 规格：{{goods.specification}}</div>
		</div>
		<div>
			<div :class='{unPrice: true}'>&yen;{{(goods.originalCost).toFixed(2)}}</div>
			<div>&yen;{{goods.goodsPriceString}}</div>
		</div>
		<div>
			<el-input-number size="small" v-model="num6"></el-input-number>
		</div>
		<div>&yen;{{goods.goodsTotlePrice}}</div>
		<div><span>删除</span></div>
	</div>
</template>
<script>
	export default{
		name: 'GoodsItem',
		props: ['goods'],
		components:{},
		data (){
			return {
				num6: 8
			}
		},
		computed: {
			
		},
		mounted(){
			
		},
		methods:{
			
		}
	}
</script>
<style lang='scss' scoped>

	.goods-item{
		display: flex;
		justify-content:space-between;
		height:140px;
		padding:20px 0;
		background-color: #fff;
		border-top: #e3e3e3 solid 1px;
		font-size: 14px;
		>div{
			&:nth-of-type(1){
				padding-left: 10px;
				width: 151px;
				display:flex;
				>input{
					width:30px;
				}
				>div{
					width:100px;
					height:100px;
					border:1px solid #e3e3e3; 
						>img{
								width:98px;
								height:98px;
						}
				}	
			}
			&:nth-of-type(2){
				width: 497px;
				display: flex;
				>div{
					padding:0 10px;
					&:nth-of-type(1){
						width: 280px;
					}
					&:nth-of-type(2){
						width:210px;	
					}
				}
			}
			&:nth-of-type(3){
				width: 150px;
					.unPrice {
					text-decoration: line-through;
				}
			}
			&:nth-of-type(4){
				width: 130px;
				.el-input-number--small{
					width:110px;
				}
				.el-input-number--small .el-input__inner{
					padding-right: 60px;
				}
			}
			&:nth-of-type(5){
				width: 140px;
				color:#f1496f;
			}
			&:nth-of-type(6){
				width: 110px;
				padding-right: 10px;
			}
		}
	}


</style>