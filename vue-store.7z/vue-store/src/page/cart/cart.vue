<template>
	<div class="cart">
		<OrderStatusBar currentStatus='1'></OrderStatusBar>
		<div class="cart-main">
			<div>
				全部商品（<span>{{productlist.totleNum}}</span>）
			</div>
			<div >
				<div><input type="checkbox" name="" value=""> 全选</div>
				<div>商品信息</div>
				<div>单价</div>
				<div>数量</div>
				<div>小计</div>
				<div>操作</div>
			</div>
			<div>
				<StoreItem v-for='(store, index) in productlist.carts' :key='index' :store='store'></StoreItem>
			</div>
		</div>
	</div>
</template>
<script>
	import  OrderStatusBar from './orderStatusBar.vue';
	import  StoreItem from './storeItem.vue';
	import { mapMutaions } from 'vuex';
	import {queryCartList} from '../../api/api.js';
	export default{
		name: 'Cart',
		components: {OrderStatusBar, StoreItem},
		data (){
			return {
				productlist:''
			}
		},
		computed: {
			
		},
		mounted(){
			queryCartList().then((res)=>{
				console.log(res)
				if(res.code === 'A0000'){
					this.productlist = res
				}
			})
		},
		methods:{
			
		}
	}
</script>
<style lang='scss' scoped>
  .cart{
		.cart-main{
			>div{
				&:nth-of-type(1){
					font-size: 14px;
					padding-left:10px;
					margin-bottom:10px;
					>span{
						color:#f1469f;
					}
				}
				&:nth-of-type(2){
					display: flex;
					justify-content: space-between;
					background: #ebebeb;
					height:43px;
					align-items:center;
					margin-bottom: 10px;
					>div{
						&:nth-of-type(1){
							padding-left: 10px;
							width: 151px;
							>input{
								background: #fff;
								border: 1px solid #3d3d3d;
							}
						}
						&:nth-of-type(2){
							width: 497px;
						}
						&:nth-of-type(3){
							width: 150px;
						}
						&:nth-of-type(4){
							width: 130px;
						}
						&:nth-of-type(5){
							width: 140px;
						}
						&:nth-of-type(6){
							width: 110px;
							padding-right: 10px;
						}
					}
				}
			}
			
		}
	}
</style>